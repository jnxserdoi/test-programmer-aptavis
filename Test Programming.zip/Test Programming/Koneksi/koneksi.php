<?php
$host = "127.0.0.1";
$username = "root";
$password = "1234";
$database = "klasemen";

$koneksi = mysqli_connect($host, $username, $password, $database);

if (mysqli_connect_errno()) {
   echo "Koneksi database gagal : " . mysqli_connect_error();
}
?>
