<?php 
		include 'koneksi/koneksi.php';
?>
<!DOCTYPE html>
<html>
<head>
	<title>CRUD PHP dan MySQLi - WWW.MALASNGODING.COM</title>
</head>
<body>
 
	<h2>Klasemen Bola</h2>
	<br/>
	<a href="1/tambah.php">Tambah Klub</a>
	<br/>
	<br/>
	<table border="1">
		<tr>
			<th>NO</th>
			<th>Nama Klub</th>
			<th>Kota Klub</th>
			<th>Aksi</th>
		</tr>
		<?php 
		$no = 1;
		$data = mysqli_query($koneksi,"select * from klub_bola");
		while($d = mysqli_fetch_array($data)){
			?>
			<tr>
				<td><?php echo $no++; ?></td>
				<td><?php echo $d['nama_klub']; ?></td>
				<td><?php echo $d['kota_klub']; ?></td>
				<td>
					<a href="1/update.php?id=<?php echo $d['id']; ?>">EDIT</a>
					<a href="1/hapus.php?id=<?php echo $d['id']; ?>">HAPUS</a>
				</td>
			</tr>
			<?php 
		}
		?>
	</table>
	</br>
	<a href="2/tambah.php">Tambah skor</a>
	<br/>
	<br/>
	<table border="1">
        <tr>
			<th>NO</th>
			<th>Home</th>
			<th>Goal(Home)</th>
			<th>Away</th>
			 <th>Goal(Away) </th>
			<th>Result</th>
			<th>Poin</th>
			<th>Aksi</th>
		</tr>
        <?php
        //menampilkan data dari database ke dalam tabel
        $no=1;
        $data= mysqli_query($koneksi,"SELECT * FROM pertandingan_skor");
         while ($d = mysqli_fetch_array($data)) {
        ?>
        <tr>
				<td><?php echo $no++; ?></td>
				<td><?php echo $d['home']; ?></td>
				<td><?php echo $d['skor1']; ?></td>
				<td><?php echo $d['away']; ?></td>
				<td><?php echo $d['skor2']; ?></td>
				<td><?php echo $d['results']; ?></td>
				<td><?php echo $d['points']; ?></td>
				<td>
					<a href="2/update.php?id=<?php echo $d['id']; ?>">EDIT</a>
					<a href="2/hapus.php?id=<?php echo $d['id']; ?>">HAPUS</a>
				</td>
			</tr>
			<?php 
		}
		?>
	</table>
	</br>
	<a href="3/tambah.php">Papan Klasemen</a>
	<br/>
	<br/>
	<table border="1">
		<tr>
			<th>NO</th>
			<th>Klub</th>
			<th>Main</th>
			<th>Menang</th>
			<th>Seri</th>
			<th>Kalah</th>
			<th>GM</th>
			<th>GK</th>
			<th>Point</th>
		</tr>
	</table>
</body>
</html>