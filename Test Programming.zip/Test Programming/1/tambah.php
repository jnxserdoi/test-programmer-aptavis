<!DOCTYPE html>
<html>
<head>
	<title>Tambah klub serta kota</title>
</head>
<body>
	<a href="../index.php">KEMBALI</a>
	<br/>
	<br/>
	
<?php

include '../Koneksi/koneksi.php';

// menangkap data yang di kirim dari form

if($_SERVER["REQUEST_METHOD"] == "POST") {
$nama_klub = $_POST['nama_klub'];
$kota_klub = $_POST['kota_klub'];
 
// menginput data ke database
// mysqli_query($koneksi,"insert into klub_bola values('', '$nama_klub','$kota_klub')") ;
$sql="insert into klub_bola(nama_klub,kota_klub)values('$nama_klub','$kota_klub')";
$hasil=mysqli_query($koneksi,$sql);
if($hasil)
{
	header("location: ../index.php");
}
else
{
echo "maning";
}
}
?>
     
	
	
	<h3>TAMBAH KLUB</h3>
	<form method="post" action="<?php echo $_SERVER["PHP_SELF"];?>">
		<table>
			<tr>			
				<td>Nama Klub</td>
				<td><input type="text" name="nama_klub"></td>
			</tr>
			<tr>
				<td>Kota Klub</td>
				<td><input type="text" name="kota_klub"></td>
			</tr>
			<tr>
				<td></td>
				<td><input type="submit" value="SIMPAN"></td>
			</tr>		
		</table>
	</form>
</body>
</html>