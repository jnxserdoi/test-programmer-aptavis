<!DOCTYPE html>
<html>
<head>
	<title>Tambah klub serta kota</title>
</head>
<body>
	<a href="../index.php">KEMBALI</a>
	<br/>
	<br/>
	
<?php 
  
  include '../Koneksi/koneksi.php';
  
  $id = $_GET['id'];
  
  $query = "SELECT * FROM klub_bola WHERE id = '$id' LIMIT 1";

  $result = mysqli_query($koneksi, $query);

  $row = mysqli_fetch_array($result);

  ?>
	<h3>TAMBAH KLUB</h3>
	<form method="post" action="validasi/validasi_update.php">
		<table>
			<tr>			
				<td>Nama Klub</td>
				<td>
                   <input type="text" name="nama_klub"  value="<?php echo $row['nama_klub'] ?>">
                   <input type="hidden" name="id" value="<?php echo $row['id'] ?>">
                 </td>
			</tr>
			<tr>
				<td>Kota Klub</td>
				<td>
                  <input type="text" name="kota_klub"  value="<?php echo $row['kota_klub'] ?>">
                </td>
			</tr>
			<tr>
				<td></td>
				<td><input type="submit" value="SIMPAN"></td>
			</tr>		
		</table>
	</form>
</body>
</html>