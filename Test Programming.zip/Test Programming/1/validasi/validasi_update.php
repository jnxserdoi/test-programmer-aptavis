<?php

//include koneksi database
include '../../Koneksi/koneksi.php';

// menangkap data yang di kirim dari form
$id = $_POST['id'];
$nama_klub = $_POST['nama_klub'];
$kota_klub = $_POST['kota_klub'];

//query update data ke dalam database berdasarkan ID
$query = "UPDATE klub_bola SET nama_klub = '$nama_klub', kota_klub = '$kota_klub' WHERE id= '$id' ";

//kondisi pengecekan apakah data berhasil diupdate atau tidak
if($koneksi->query($query)) {
    //redirect ke halaman index.php 
    header("location: ../../index.php");
} else {
    //pesan error gagal update data
    echo "Data Gagal Diupate!";
}

?>