<!DOCTYPE html>
<html>
<head>
  <title>Input Pertandingan</title>
</head>
<body>

<?php
include '../Koneksi/koneksi.php';

//function input($data) 
//{
	//$data=trim($data);
	//$data=stripslashes($data);
	//$data=htmlspecialchars($data);
	//return $data;
//}

if($_SERVER["REQUEST_METHOD"] == "POST") 
//if(isset($_POST['submit'])) 
{
$home =($_POST['home']) ;
$away = ($_POST['away']);
$skor1 =($_POST['skor1']);
$skor2 =($_POST['skor2']);

//menggabungkan 2 tim yang akan bertanding menjadi satu field pertandingan
    //$pertandingan = implode(" vs ", array($home, $away));
    //$hasil= implode ("-", array($skor1,$skor2));
    //menghitung skor dari pertandingan
  if ($skor1 > $skor2) {
     $hasil= $home."- menang";
     $poin= 3;
   } elseif ($skor2 > $skor1) {
      $hasil = $away."- menang";
      $poin = 3;
 } elseif ($skor1 == $skor1){
    $hasil = "Seri";
    $poin=1;
 }else{
   $hasil="kalah WO";
   $poin=0;
}
 
// menginput data ke database
// mysqli_query($koneksi,"insert into klub_bola values('', '$nama_klub','$kota_klub')") ;
//menyimpan data ke dalam database
    $sql= "INSERT INTO pertandingan_skor (home, away, skor1, skor2, points, results) VALUES ('$home', '$away', '$skor1', '$skor2', '$poin', '$hasil')";
    $hasil= mysqli_query($koneksi, $sql);
if($hasil)
{
	header("location: index.php");
	exit;
}
else
{
    echo " lu";
}
}

?>
  <form id="match" action="<?php echo $_SERVER["PHP_SELF"];?>" method="post">
    <div>
      <label for="home">Home Team:</label>
      <select name="home" id="home" required>
    <?php
      // query untuk mengambil daftar kategori dari database
      $sql = "SELECT nama_klub FROM klub_bola";
      $result = mysqli_query($koneksi, $sql);
      // tampilkan daftar kategori sebagai opsi dalam elemen select
      while($row = mysqli_fetch_assoc($result)) {
        echo '<option value="' . $row['nama_klub'] . '">' .$row['nama_klub'].'</option>';
      }
    ?>
  </select>
    </div>
   
    <div>
      <label for="skor1">Skor 1:</label>
      <input type="number" id="skor1" name="skor1" required>
    </div>
    
    <div>
      <label for="away">Away Team:</label>
      <select name="away" id="away" required>
    <?php
      // query untuk mengambil daftar kategori dari database
      $sql = "SELECT nama_klub FROM klub_bola order by id DESC";
      $result = mysqli_query($koneksi, $sql);
      // tampilkan daftar kategori sebagai opsi dalam elemen select
      while($row = mysqli_fetch_assoc($result)) {
        echo '<option value="' . $row['nama_klub'] . '">' . $row['nama_klub'] . '</option>';
      }
    ?>
    	<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
  $(function() {
    $('#match').on('submit', function(e) {
      var home = $('select[name="home"]').val();
      var away = $('select[name="away"]').val();

      // Validasi
      if (home === away) {
        alert("Pilihan 1 dan pilihan 2 tidak boleh sama.");
        e.preventDefault();
      }
    });
  });
</script>
  </select>
    </div>
    
    <div>
      <label for="skor2">Skor 2:</label>
      <input type="number" id="skor2" name="skor2" required>
    </div>
    <div>
      <button type="submit">Tambahkan</button>
      <button type="button" onclick="window.location.href='../index.php';">Kembali</button>
    </div>
  </form>
</body>

</html>