<?php

//include koneksi database
include '../../Koneksi/koneksi.php';

// menangkap data yang di kirim dari form
$id = $_POST['id'];
$home =$_POST['home'];
$away = $_POST['away'];
$skor1 =$_POST['skor1'];
$skor2 =$_POST['skor2'];
if ($skor1 > $skor2) {
     $hasil= $home."- menang";
     $poin= 3;
   } elseif ($skor2 > $skor1) {
      $hasil = $away."- menang";
      $poin = 3;
 } elseif ($skor1 == $skor1){
    $hasil = "Seri";
    $poin=1;
 }else{
   $hasil="kalah WO";
   $poin=0;
}

//query update data ke dalam database berdasarkan ID
$query = "UPDATE pertandingan_skor SET home = '$home', away = '$away', skor1='$skor1', skor2= '$skor2'  , points='$poin' , results='$hasil' WHERE id= '$id' ";

//kondisi pengecekan apakah data berhasil diupdate atau tidak
if($koneksi->query($query)) {
    //redirect ke halaman index.php 
    header("location: ../index.php");
} else {
    //pesan error gagal update data
    echo "Data Gagal Diupate!";
}

?>